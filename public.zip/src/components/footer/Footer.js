import './footer.css'
export default function Footer() {
    return (
        <div className="wrapper">
            <p className="footer">Виконано в <a target="_blank" href="https://prometheus.org.ua/"> Prometheus</a> © 2022</p> 
        </div>
    )
}
