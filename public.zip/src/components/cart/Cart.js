import "./cart.css";
import Header from '../header/Header';
import Footer from "../footer/Footer";
import cart from './img/cart.svg'

export default function Cart() {
    if (!localStorage.username) {
        document.location = "/"
    }
    window.addEventListener('DOMContentLoaded', () => {
            let cartBooks = [{
                "id": 1,
                "author": "David Flanagan",
                "price": 10.99,
                "image": "https://courses.prometheus.org.ua/asset-v1:Ciklum+FEB101+2022_T3+type@asset+block@javascript_the_definitive_guide.jpg",
                "title": "JavaScript: The Definitive Guide, 7th Edition",
                "shortDescription": "JavaScript is the programming language of the web and is used by more software developers today than any other programming language.",
                "description": "JavaScript is the programming language of the web and is used by more software developers today than any other programming language. For nearly 25 years this best seller has been the go-to guide for JavaScript programmers. The seventh edition is fully updated to cover the 2020 version of JavaScript, and new chapters cover classes, modules, iterators, generators, Promises, async/await, and metaprogramming. You’ll find illuminating and engaging example code throughout. This book is for programmers who want to learn JavaScript and for web developers who want to take their understanding and mastery to the next level. It begins by explaining the JavaScript language itself, in detail, from the bottom up. It then builds on that foundation to cover the web platform and Node.js."
            },
            {
                "id": 2,
                "author": "James Padolsey",
                "price": 31.99,
                "image": "",
                "title": "Clean Code in JavaScript",
                "shortDescription": "Building robust apps starts with creating clean code. In this book, you'll explore techniques for doing this by learning everything from the basics of JavaScript through to the practices of clean code. You'll write functional, intuitive, and maintainable code while also understanding how your code affects the end user and the wider community.",
                "description": "Building robust apps starts with creating clean code. In this book, you'll explore techniques for doing this by learning everything from the basics of JavaScript through to the practices of clean code. You'll write functional, intuitive, and maintainable code while also understanding how your code affects the end user and the wider community. The book starts with popular clean-coding principles such as SOLID, and the Law of Demeter (LoD), along with highlighting the enemies of writing clean code such as cargo culting and over-management. You'll then delve into JavaScript, understanding the more complex aspects of the language. Next, you'll create meaningful abstractions using design patterns, such as the Class Pattern and the Revealing Module Pattern. You'll explore real-world challenges such as DOM reconciliation, state management, dependency management, and security, both within browser and server environments. Later, you'll cover tooling and testing methodologies and the importance of documenting code. Finally, the book will focus on advocacy and good communication for improving code cleanliness within teams or workplaces, along with covering a case study for clean coding. By the end of this book, you'll be well-versed with JavaScript and have learned how to create clean abstractions, test them, and communicate about them via documentation."
            },
            {
                "id": 3,
                "author": "Adam D. Scott",
                "price": 8.99,
                "image": "https://courses.prometheus.org.ua/asset-v1:Ciklum+FEB101+2022_T3+type@asset+block@javascript_everywhere.jpg",
                "title": "JavaScript Everywhere",
                "shortDescription": "JavaScript is the little scripting language that could. Once used chiefly to add interactivity to web browser windows, JavaScript is now a primary building block of powerful and robust applications.",
                "description": "JavaScript is the little scripting language that could. Once used chiefly to add interactivity to web browser windows, JavaScript is now a primary building block of powerful and robust applications. In this practical book, new and experienced JavaScript developers will learn how to use this language to create APIs as well as web, mobile, and desktop applications. Author and engineering leader Adam D. Scott covers technologies such as Node.js, GraphQL, React, React Native, and Electron. Ideal for developers who want to build full stack applications and ambitious web development beginners looking to bootstrap a startup, this book shows you how to create a single CRUD-style application that will work across several platforms."
            }]
        
        const main = document.getElementsByClassName('main')[0];
        let total = document.getElementById('total');

        if (cartBooks.length === 0) {
            document.getElementsByClassName('purchase')[0].disabled = true;
            document.querySelector(".main img").classList.remove("none");
            document.querySelector(".main span").classList.remove("none");
            total.classList.add('none');
        }
        else if (cartBooks.length >= 1) {
            document.getElementsByClassName('purchase')[0].disabled = false;
            document.querySelector(".main img").classList.add("none");
            document.querySelector(".main span").classList.add("none");
            total.classList.remove('none');
            
            let totalPrice = 0;

            let count = JSON.parse(localStorage.getItem("bookCount"));

            cartBooks.forEach((el) => {
                
                const cartBook = document.createElement('div');
                cartBook.classList.add('cartBook');
                main.append(cartBook);
                
                cartBook.innerHTML = `
                <p class="cart-text"><b>Book name: </b>${el.title}</p>
                <p class="cart-price"><b>Book count: </b>${count}</p>
                <p class="cart-price"><b>Price, $</b> ${el.price*count}</p>
                `
                totalPrice += el.price * count;
                total.textContent = `Total price,$ ${totalPrice.toFixed(2)}`
            })


        }
    })

    return (
        <>
            <section className="header">
                <Header />
            </section>

            <div className="main">
                <button className="purchase">Purchase</button>

                <img src={cart} alt="cart" />
                <span>Cart empty..</span>
                <p id="total"></p>
            </div>

            <Footer />
        </>
    )
}
