import Book from "./Book";
export default function Shelf(props) {
    //console.log(props.props);
    //return
    return (
        <section className="book-list">
            
            {props.props.map((el, i) => (
                <Book item={el} key={i} />

            ))}
        </section>
    )
}
