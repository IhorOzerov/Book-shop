import { Link } from "react-router-dom";
export default function Book(props) {

    
    let title;
    if (props.item.title.length >= 24) {
        title = (props.item.title.slice(0, 24) + "...")
    } else {
        title = props.title
    }

    return (
        <>
            <div className="book" id={props.key}>
                <img src={props.image == "" ? title : props.item.image} alt="myFace"/>
                <p className="book-text"><b>Book name: </b>{title}</p>
                <p className="book-text"><b>Book author: </b>{props.item.author}</p>
                <div className="book-price">
                    <p className="book-text"><b>Price, $</b> {props.item.price}</p>
                    <Link to="specificbook"><button className="view-btn">View</button></Link>
                </div>
            </div>
        </>
    )
}
