import './bookList.css';
import notFound from './img/imageNotFound.png';
import data from "./books.json";
import Footer from "../footer/Footer";
import Header from '../header/Header';
import { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import Shelf from './Shelf';

const responseData = []
responseData.push(...data.books);



export default function BookList() {
    const getBooks = (arr) => {
        arr.forEach((user) => {
            const newBook = document.createElement('div');
            newBook.classList.add('book');

            document.querySelector('.book-list').appendChild(newBook);/////
            let title;
            if (user.title.length >= 24) {
                title = (user.title.slice(0, 24) + "...")
            } else {
                title = user.title
            }

            /*let link = document.createElement('Link'); 
            link.setAttribute('to', '/specificbook')*/
            
            newBook.innerHTML = `
            <img src="${user.image == "" ? notFound : user.image}" alt="myFace">
            <p class="book-text"><b>Book name: </b>${title}</p>
            <p class="book-text"><b>Book author: </b>${user.author}</p>
            <div class="book-price">
                <p class="book-text"><b>Price, $</b> ${user.price}</p>
                <Link className="view-btn" to="specificbook">View</Link>
                
                
            </div>
        `
            
        });
    }
    const [input, setInput] = useState('');
    const [select, setSelect] = useState('default')

    if (!localStorage.username) {
        document.location = "/"
    }
    useEffect(() => {
        getBooks(responseData);
    }, [responseData])

        
    useEffect(() => {
        findBook();
    }, [input, select])
    
    const findBook = () => {
        let sortedBooks = [...responseData];

        sortedBooks = sortedBooks.filter(el => el.title
            .toLowerCase()
            .includes(input
                .trim()
                .toLowerCase()));
        
        if (select === "lowPrice") {
            sortedBooks = sortedBooks.filter(el => el.price <= 15)
                                    .sort((a, b) => a.price - b.price);
        } else if (select === "midPrice") {
            sortedBooks = sortedBooks.filter(el => el.price > 15 && el.price <= 30)
                                    .sort((a, b) => a.price - b.price);
        } else if (select === "highPrice") {
            sortedBooks = sortedBooks.filter(el => el.price > 30)
                                    .sort((a,b)=> a.price-b.price);
        } else {
            getBooks(sortedBooks)
        }
        document.getElementsByClassName('book-list')[0].innerHTML = '';
        getBooks(sortedBooks);
    }
    
    return (
        <>
            <section className="header">
                <Header />
            </section>
            

            <section className="filters">

                <input onInput={findBook} onChange={e => setInput(e.target.value)}  type="search" id="searchName" placeholder="Search by book name" />
                
                <select onChange={findBook} onInput={e => setSelect(e.target.value)} id="sortPrice" autoComplete="off">
                    <option value="default">default</option>
                    <option value="lowPrice">from 0 to 15</option>
                    <option value="midPrice">from 15 to 30</option>
                    <option value="highPrice">more than 30</option>
                </select>
            </section>
                                                                        <Shelf props={responseData} />
            <section className="book-list"></section>

            <Footer />
        </>
    )
    
}






