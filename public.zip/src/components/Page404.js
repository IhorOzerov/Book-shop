export default function Error404() {
    return (
        <>
            <p>“Oops, something went wrong. 404 error”</p>
        </>
    )
}
