import './specBook.css';
import bookImg from './img/javascript_everywhere.jpg';
import Footer from "../footer/Footer";
import Header from '../header/Header';
import {useState, useMemo} from 'react'



export default function SpecificBook() {

    const [count, setCount] = useState(1);

    let totaBooklPrice = useMemo(() => '$' + 17 * count, [count])
    

    console.log(count, totaBooklPrice.slice(1)); //data

    if (!localStorage.username) {
        document.location = "/"
    }



    window.addEventListener('DOMContentLoaded', () => {
        let addBtn = document.querySelector('.price-block-btn')

        addBtn.addEventListener('click', () => {
            /*localStorage.setItem('totalPrice', totalPrice.textContent.slice(1));
            localStorage.setItem("bookCount", count.value);*/
        })
    });
    

    return (
        <>
            <section className="header">
                <Header />
            </section>
            
                
            <section className="book-page">
                <figure>
                    <img src={bookImg} alt="javascript everywhere"/>
                        <figcaption>
                            <p>
                                <b>Description: </b>
                                A book providing an introduction to the JavaScript language and programming in general
                            </p>
                        </figcaption>
                </figure>
                <section className="about">
                    <p><b>Book name: </b>Javascript Everywhere</p>
                    <p><b>Book author:</b> Adam D. Scott</p>
                    <p><b>Book level:</b> Beginner</p>
                    <p><b>Book tags:</b> Core</p>
                </section>
                <section className="price-block">
                    <div className="price-block-row">
                        <span>Price, $ </span>
                        <span id="price">17</span>
                    </div>
                    <div className="price-block-row">
                        <label htmlFor="count">Count:</label>
                        <input onChange={(e) => setCount(e.target.value)} type="number" id="count" min="1" max="42" value={count} />
                    </div>
                    <div className="price-block-row">
                        <span>Total price </span>
                        <span id="totalPrice">{totaBooklPrice}</span>
                    </div>
                    <button className="price-block-btn" type="submit">Add to cart</button>
                </section>
            </section>
            <Footer />
        </>
    )
}
